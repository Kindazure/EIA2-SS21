var eia10_2;
(function (eia10_2) {
    var Landscape = /** @class */ (function () {
        function Landscape(x, y, height) {
            this.x = x;
            this.y = y;
            this.height = height;
        }
        Landscape.prototype.draw = function () { };
        return Landscape;
    }());
    eia10_2.Landscape = Landscape;
})(eia10_2 || (eia10_2 = {}));
//# sourceMappingURL=landscape.js.map