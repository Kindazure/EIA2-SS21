namespace eia10_2 {
    export class Animated {
        update(): void {}
        draw(): void {}
    }
}