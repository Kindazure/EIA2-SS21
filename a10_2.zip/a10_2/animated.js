var eia10_2;
(function (eia10_2) {
    var Animated = /** @class */ (function () {
        function Animated() {
        }
        Animated.prototype.update = function () { };
        Animated.prototype.draw = function () { };
        return Animated;
    }());
    eia10_2.Animated = Animated;
})(eia10_2 || (eia10_2 = {}));
//# sourceMappingURL=animated.js.map