var eia10_2;
(function (eia10_2) {
    eia10_2.canvas = document.getElementById("canvas");
    eia10_2.c = eia10_2.canvas.getContext("2d");
})(eia10_2 || (eia10_2 = {}));
//# sourceMappingURL=init.js.map